<?php
$handle=null;
?>