<?php
require('sql/sql.php');
		$con=new sql;
		$con->listar();

?>